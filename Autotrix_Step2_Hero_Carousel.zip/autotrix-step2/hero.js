/* STEP 2: HERO CAROUSEL | Paste at the END of your existing script.js */
(() => {
  const hero = document.querySelector('.atx-hero');
  if (!hero) return;

  const slides = [...hero.querySelectorAll('.atx-hero-slide')];
  const dots = [...hero.querySelectorAll('[data-dot]')];
  const prev = hero.querySelector('.atx-hero-prev');
  const next = hero.querySelector('.atx-hero-next');
  const counter = hero.querySelector('[data-hero-current]');
  const announcement = hero.querySelector('[data-hero-announcement]');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let active = 0;
  let timer = null;
  let pointerInside = false;
  let focusInside = false;
  let touchStartX = 0;
  let touchStartY = 0;

  function showSlide(index, userInitiated = false) {
    active = (index + slides.length) % slides.length;
    slides.forEach((slide, i) => {
      const current = i === active;
      slide.classList.toggle('is-active', current);
      slide.setAttribute('aria-hidden', String(!current));
      slide.toggleAttribute('inert', !current);
    });
    dots.forEach((dot, i) => {
      dot.classList.toggle('is-active', i === active);
      if (i === active) dot.setAttribute('aria-current', 'true');
      else dot.removeAttribute('aria-current');
    });
    if (counter) counter.textContent = String(active + 1).padStart(2, '0');
    if (userInitiated && announcement) {
      announcement.textContent = `Slide ${active + 1} of ${slides.length}`;
    }
  }

  function stopAutoplay() {
    window.clearInterval(timer);
    timer = null;
  }
  function startAutoplay() {
    stopAutoplay();
    if (reducedMotion.matches || document.hidden || pointerInside || focusInside) return;
    timer = window.setInterval(() => showSlide(active + 1), 5500);
  }
  function navigate(step) {
    showSlide(active + step, true);
    startAutoplay();
  }

  prev.addEventListener('click', () => navigate(-1));
  next.addEventListener('click', () => navigate(1));
  dots.forEach((dot, index) => dot.addEventListener('click', () => {
    showSlide(index, true);
    startAutoplay();
  }));

  hero.addEventListener('mouseenter', () => { pointerInside = true; stopAutoplay(); });
  hero.addEventListener('mouseleave', () => { pointerInside = false; startAutoplay(); });
  hero.addEventListener('focusin', () => { focusInside = true; stopAutoplay(); });
  hero.addEventListener('focusout', event => {
    if (!hero.contains(event.relatedTarget)) { focusInside = false; startAutoplay(); }
  });
  hero.addEventListener('keydown', event => {
    if (event.key === 'ArrowRight') { event.preventDefault(); navigate(1); }
    if (event.key === 'ArrowLeft') { event.preventDefault(); navigate(-1); }
  });
  hero.addEventListener('touchstart', event => {
    touchStartX = event.changedTouches[0].screenX;
    touchStartY = event.changedTouches[0].screenY;
    stopAutoplay();
  }, { passive: true });
  hero.addEventListener('touchend', event => {
    const deltaX = event.changedTouches[0].screenX - touchStartX;
    const deltaY = event.changedTouches[0].screenY - touchStartY;
    if (Math.abs(deltaX) > 55 && Math.abs(deltaX) > Math.abs(deltaY) * 1.5) {
      navigate(deltaX < 0 ? 1 : -1);
    } else {
      startAutoplay();
    }
  }, { passive: true });
  document.addEventListener('visibilitychange', startAutoplay);
  reducedMotion.addEventListener('change', startAutoplay);

  showSlide(0);
  startAutoplay();
})();
