AUTOTRIX | STEP 2 - HERO CAROUSEL

WHAT IS INCLUDED
- index.html = ready-to-open header + hero carousel
- style.css = your previous header CSS + new hero CSS
- script.js = your previous header JS + new hero JS
- hero.html = hero-only HTML snippet
- hero.css = hero-only CSS snippet
- hero.js = hero-only JavaScript snippet
- assets/ = demo photos cropped from our earlier approved design reference

OPTION A (EASIEST)
Extract the ZIP, open index.html in your browser. It includes the Step 1 header and Step 2 hero.

OPTION B (ADD TO EXISTING PROJECT)
1. Paste hero.html inside your existing <main id="home">.
2. Copy hero.css to the end of your existing style.css.
3. Copy hero.js to the end of your existing script.js.
4. Copy the assets folder next to index.html.

IMPORTANT
- 4 slides: Vehicle Tint, Building Tint, Storefront Signs, Commercial Vehicle Graphics.
- Slider has arrows, dots, autoplay, pause on hover/focus, keyboard and mobile swipe.
- Quote CTAs currently open an email to autotrixgraphics@gmail.com.
  When the contact form is ready, change their href to #contact.
- Images are visual reference placeholders, NOT verified Autotrix project photos.
  Replace these with licensed/approved high-quality photos before launch.
- Other navigation section anchors will work when those sections get created.
