const menuButton = document.querySelector('.atx-menu-toggle');
const nav = document.querySelector('.atx-nav');
const servicesButton = document.querySelector('.atx-services-toggle');
const dropdown = document.querySelector('.atx-dropdown');

function closeServices() {
  dropdown.classList.remove('is-open');
  servicesButton.setAttribute('aria-expanded', 'false');
}
function closeMenu() {
  nav.classList.remove('is-open');
  menuButton.classList.remove('is-open');
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.setAttribute('aria-label', 'Open menu');
  closeServices();
}

menuButton.addEventListener('click', () => {
  const open = !nav.classList.contains('is-open');
  nav.classList.toggle('is-open', open);
  menuButton.classList.toggle('is-open', open);
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  if (!open) closeServices();
});

servicesButton.addEventListener('click', () => {
  const open = !dropdown.classList.contains('is-open');
  dropdown.classList.toggle('is-open', open);
  servicesButton.setAttribute('aria-expanded', String(open));
});

// Close menus after choosing a link.
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));

// Close on Escape or a click outside the header.
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeMenu();
});
document.addEventListener('click', event => {
  if (!event.target.closest('.atx-header')) closeMenu();
});

// Reset the mobile state when the screen becomes desktop sized.
window.matchMedia('(min-width: 1101px)').addEventListener('change', closeMenu);


/* STEP 2: HERO CAROUSEL | Paste at the END of your existing script.js */
(() => {
  const hero = document.querySelector('.atx-hero');
  if (!hero) return;

  const slides = [...hero.querySelectorAll('.atx-hero-slide')];
  const dots = [...hero.querySelectorAll('[data-dot]')];
  const prev = hero.querySelector('.atx-hero-prev');
  const next = hero.querySelector('.atx-hero-next');
  const counter = hero.querySelector('[data-hero-current]');
  const announcement = hero.querySelector('[data-hero-announcement]');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let active = 0;
  let timer = null;
  let pointerInside = false;
  let focusInside = false;
  let touchStartX = 0;
  let touchStartY = 0;

  function showSlide(index, userInitiated = false) {
    active = (index + slides.length) % slides.length;
    slides.forEach((slide, i) => {
      const current = i === active;
      slide.classList.toggle('is-active', current);
      slide.setAttribute('aria-hidden', String(!current));
      slide.toggleAttribute('inert', !current);
    });
    dots.forEach((dot, i) => {
      dot.classList.toggle('is-active', i === active);
      if (i === active) dot.setAttribute('aria-current', 'true');
      else dot.removeAttribute('aria-current');
    });
    if (counter) counter.textContent = String(active + 1).padStart(2, '0');
    if (userInitiated && announcement) {
      announcement.textContent = `Slide ${active + 1} of ${slides.length}`;
    }
  }

  function stopAutoplay() {
    window.clearInterval(timer);
    timer = null;
  }
  function startAutoplay() {
    stopAutoplay();
    if (reducedMotion.matches || document.hidden || pointerInside || focusInside) return;
    timer = window.setInterval(() => showSlide(active + 1), 5500);
  }
  function navigate(step) {
    showSlide(active + step, true);
    startAutoplay();
  }

  prev.addEventListener('click', () => navigate(-1));
  next.addEventListener('click', () => navigate(1));
  dots.forEach((dot, index) => dot.addEventListener('click', () => {
    showSlide(index, true);
    startAutoplay();
  }));

  hero.addEventListener('mouseenter', () => { pointerInside = true; stopAutoplay(); });
  hero.addEventListener('mouseleave', () => { pointerInside = false; startAutoplay(); });
  hero.addEventListener('focusin', () => { focusInside = true; stopAutoplay(); });
  hero.addEventListener('focusout', event => {
    if (!hero.contains(event.relatedTarget)) { focusInside = false; startAutoplay(); }
  });
  hero.addEventListener('keydown', event => {
    if (event.key === 'ArrowRight') { event.preventDefault(); navigate(1); }
    if (event.key === 'ArrowLeft') { event.preventDefault(); navigate(-1); }
  });
  hero.addEventListener('touchstart', event => {
    touchStartX = event.changedTouches[0].screenX;
    touchStartY = event.changedTouches[0].screenY;
    stopAutoplay();
  }, { passive: true });
  hero.addEventListener('touchend', event => {
    const deltaX = event.changedTouches[0].screenX - touchStartX;
    const deltaY = event.changedTouches[0].screenY - touchStartY;
    if (Math.abs(deltaX) > 55 && Math.abs(deltaX) > Math.abs(deltaY) * 1.5) {
      navigate(deltaX < 0 ? 1 : -1);
    } else {
      startAutoplay();
    }
  }, { passive: true });
  document.addEventListener('visibilitychange', startAutoplay);
  reducedMotion.addEventListener('change', startAutoplay);

  showSlide(0);
  startAutoplay();
})();


/* STEP 4 + STEP 5: Animate tinting sections when they enter the screen.
   This script is optional: without JS all content is still visible. */
(() => {
  const elements = [...document.querySelectorAll('.atx-tint-services .atx-reveal, .atx-tint-benefits .atx-reveal')];
  if (!elements.length) return;

  if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    });
  }, { rootMargin: '0px 0px -45px 0px', threshold: 0.07 });

  // Only enable hidden-before-reveal style AFTER the observer is ready.
  document.documentElement.classList.add('atx-enhanced');
  elements.forEach((item) => observer.observe(item));
})();
